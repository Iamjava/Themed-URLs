# colortabs
Firefox add-on to switch browser theme color based on domain
